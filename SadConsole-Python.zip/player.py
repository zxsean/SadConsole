import clr

# Add references to MonoGame and SadConsole
clr.AddReference("SadConsole/MonoGame.Framework")
clr.AddReference("SadConsole/SadConsole.Core.Windows")

from Microsoft.Xna.Framework import Point
from System.Collections.Generic import LinkedList
from SadConsole.Input import KeyboardInfo
from Microsoft.Xna.Framework.Input import Keys

# Direction values
dir_up = 0
dir_down = 1
dir_left = 2
dir_right = 3

TailLength = 1
Position = Point(0, 0)
MaxTailLength = 3
CurrentDirection = dir_right
TailNodes = LinkedList[Point]()
RemoveNodes = LinkedList[Point]()

def Reset():
    global TailLength, Position, CurrentDirection, MaxTailLength

    TailLength = 1
    Position = Point(18, 18)
    SetStartingPosition(Position)
    CurrentDirection = dir_right
    MaxTailLength = 3

    TailNodes.Clear()
    RemoveNodes.Clear()

def ProcessKeyboard(console, info):
    global CurrentDirection
    keyHit = False
    if info.IsKeyDown(Keys.Up):
        if CurrentDirection != dir_down:
            CurrentDirection = dir_up

        keyHit = True

    elif info.IsKeyDown(Keys.Down):
        if CurrentDirection != dir_up:
            CurrentDirection = dir_down

        keyHit = True

    elif info.IsKeyDown(Keys.Left):
        if CurrentDirection != dir_right:
            CurrentDirection = dir_left

        keyHit = True

    elif info.IsKeyDown(Keys.Right):
        if CurrentDirection != dir_left:
            CurrentDirection = dir_right

        keyHit = True

    return keyHit


def moveLeft():
    global Position
    Position = Point(Position.X - 1, Position.Y)

def moveRight():
    global Position
    Position = Point(Position.X + 1, Position.Y)

def moveUp():
    global Position
    Position = Point(Position.X, Position.Y - 1)

def moveDown():
    global Position
    Position = Point(Position.X, Position.Y + 1)

moveActions = {
    dir_up : moveUp,
    dir_down : moveDown,
    dir_left : moveLeft,
    dir_right : moveRight
}

def Move():
    moveActions[CurrentDirection]()


def SetStartingPosition(point):
    TailNodes.AddFirst(point)
    pass

def ProcessTail(point):
    global TailLength

    TailNodes.AddFirst(point)

    if TailLength >= MaxTailLength:
        RemoveNodes.Clear()
        RemoveNodes.AddFirst(TailNodes.Last.Value)
        TailNodes.RemoveLast()
        TailLength -= 1

    TailLength += 1
        