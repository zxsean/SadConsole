import clr

# Add references to MonoGame and SadConsole
clr.AddReference("SadConsole/MonoGame.Framework")
clr.AddReference("SadConsole/SadConsole.Core.Windows")

# Import handy namespaces and types from .NET
import Microsoft.Xna.Framework as Xna
from SadConsole.Consoles import Console, TextSurface
from SadConsole.Effects import Fade
from System import DateTime, TimeSpan, Array
import SadConsole
import System

# Import python stuff
import random
random.seed()

# Import game stuff
import player
#player.DebugWrite = DebugWrite

# Constants
phoneButtonColumn1 = 16
phoneButtonColumn2 = 23
phoneButtonColumn3 = 30
phoneButtonRow1 = 32
phoneButtonRow2 = 37
phoneButtonRow3 = 42
phoneButtonRow4 = 47
gameStateMenu = 0
gameStateRunning = 1
gameStateOver = 2

# Globals
currentScore = 0
gameState = gameStateMenu
wafer = Xna.Point(0, 0)
gameSpeedMs = 100
gameSpeed = TimeSpan(0, 0, 0, 0, gameSpeedMs)
lastUpdate = DateTime.Now

gameStateHandlers = {

}



# Effect for pressing phone buttons
fadeEffect = Fade()
fadeEffect.RemoveOnFinished = True
fadeEffect.AutoReverse = True
fadeEffect.DestinationForeground = Xna.ColorGradient([Xna.Color.Turquoise])
fadeEffect.FadeForeground = True
fadeEffect.Repeat = False
fadeEffect.FadeDuration = 0.2
fadeEffect.CloneOnApply = True

# ===============================
# Game Logic
# ===============================

def CollisionDetectionWall(position):
    if (position.X == 14) or (position.X == 36) or (position.Y == 13) or (position.Y == 23):
        return True
    return False

def CollisionDetectionSelf(position):
    first = True
    for node in player.TailNodes:
        if first:
            first = False
        elif (position.X == node.X) and (position.Y == node.Y):
            return True

    return False

def CollisionDetection(position):
    if CollisionDetectionWall(position):
        return True
    elif CollisionDetectionSelf(position):
        return True
    
    return False

def CreateRandomWaferLocation():
    global wafer
    retry = True
    while retry:
        wafer = Xna.Point(random.randint(15, 34), random.randint(14, 21))
        retry = CollisionDetection(wafer)
    
def EndGame():
    global gameState

    phoneConsole.Print(23, 15, "GAME", Xna.Color.Black, Xna.Color.DarkSeaGreen)
    phoneConsole.Print(23, 17, "OVER", Xna.Color.Black, Xna.Color.DarkSeaGreen)

    phoneConsole.Print(21, 20, "Press * to", Xna.Color.Black, Xna.Color.DarkSeaGreen)
    phoneConsole.Print(23, 21, "Exit", Xna.Color.Black, Xna.Color.DarkSeaGreen)

    gameState = gameStateOver

# ===============================
# Screen elements
# ===============================

def AttachButtonAnimation(x, y):
    cells = []
    surf = SadConsole.Consoles.SurfaceEditor(phoneConsole.TextSurface)
    for a in range(x, x + 5):
        for b in range(y, y + 3):
            cells.append(surf[a, b])
            #cells.append(phoneConsole.get_Item(a, b))
            
    phoneConsole.SetEffect(Array[SadConsole.Cell](cells), fadeEffect)

def DrawPhoneButton(x, y, text):
    for a in range(x, x + 5):
        for b in range(y, y + 3):
            phoneConsole.SetGlyph(a, b, 219, Xna.Color.Gray)

    phoneConsole.Print(x + 2, y + 1, text, Xna.Color.Black, Xna.Color.Gray)    

def ClearScreen():
    for x in range(14, 37):
        for y in range(12, 24):
            phoneConsole.SetGlyph(x, y, 219, Xna.Color.DarkSeaGreen)

def CreateStartMessage():
    phoneConsole.Print(23, 14, "ASCII", Xna.Color.Black, Xna.Color.DarkSeaGreen)
    phoneConsole.Print(23, 16, "SNAKE", Xna.Color.Black, Xna.Color.DarkSeaGreen)
    phoneConsole.Print(21, 20, "Press * to", Xna.Color.Black, Xna.Color.DarkSeaGreen)
    phoneConsole.Print(23, 21, "Start", Xna.Color.Black, Xna.Color.DarkSeaGreen)

def DrawScore():
    scoreString = System.String(str(currentScore))
    scoreString = scoreString.PadLeft(5)
    phoneConsole.Print(14, 12, scoreString, Xna.Color.Black, Xna.Color.DarkSeaGreen)

def DrawGameBorder():
    
    for x in range(15, 36):
        phoneConsole.SetGlyph(x, 13, 196, Xna.Color.Black, Xna.Color.DarkSeaGreen)
        phoneConsole.SetGlyph(x, 23, 196, Xna.Color.Black, Xna.Color.DarkSeaGreen)

    for y in range(14, 23):
        phoneConsole.SetGlyph(14, y, 179, Xna.Color.Black, Xna.Color.DarkSeaGreen)
        phoneConsole.SetGlyph(36, y, 179, Xna.Color.Black, Xna.Color.DarkSeaGreen)

    phoneConsole.SetGlyph(14, 13, 218, Xna.Color.Black, Xna.Color.DarkSeaGreen)
    phoneConsole.SetGlyph(36, 13, 191, Xna.Color.Black, Xna.Color.DarkSeaGreen)
    phoneConsole.SetGlyph(14, 23, 192, Xna.Color.Black, Xna.Color.DarkSeaGreen)
    phoneConsole.SetGlyph(36, 23, 217, Xna.Color.Black, Xna.Color.DarkSeaGreen)

    

# ===============================
# Keyboard handlers
# ===============================

def KeyboardHandlerMenu(console, keystate):
    global gameState
    if keystate.IsKeyReleased(Xna.Input.Keys.Multiply):
        AttachButtonAnimation(phoneButtonColumn1, phoneButtonRow4)
        ResetGame()
        gameState = gameStateRunning

    return True

def KeyboardHandlerGameOver(console, keystate):
    global gameState
    if keystate.IsKeyReleased(Xna.Input.Keys.Multiply):
        AttachButtonAnimation(phoneButtonColumn1, phoneButtonRow4)
        ClearScreen()
        CreateStartMessage()
        gameState = gameStateMenu

    return True

def KeyboardHandlerGameRunning(console, keystate):

    if player.ProcessKeyboard(console, keystate):

        if keystate.IsKeyDown(Xna.Input.Keys.Up):
            AttachButtonAnimation(phoneButtonColumn2, phoneButtonRow1)

        elif keystate.IsKeyDown(Xna.Input.Keys.Down):
            AttachButtonAnimation(phoneButtonColumn2, phoneButtonRow3)
    
        elif keystate.IsKeyDown(Xna.Input.Keys.Left):
            AttachButtonAnimation(phoneButtonColumn1, phoneButtonRow2)

        elif keystate.IsKeyDown(Xna.Input.Keys.Right):
            AttachButtonAnimation(phoneButtonColumn3, phoneButtonRow2)
            
        return True

    return False


def KeyboardHandlerMain(console, keystate):
    gameStateHandlers[gameState](console, keystate)
            
    return True


gameStateHandlers = {
    gameStateRunning: KeyboardHandlerGameRunning,
    gameStateMenu: KeyboardHandlerMenu,
    gameStateOver: KeyboardHandlerGameOver
}


def ResetGame():
    ClearScreen()
    currentScore = 0
    DrawScore()
    DrawGameBorder()
    player.Reset()
    player.SetStartingPosition(player.Position)
    phoneConsole.SetGlyph(player.Position.X, player.Position.Y, 1, Xna.Color.Black, Xna.Color.DarkSeaGreen)
    CreateRandomWaferLocation()
    phoneConsole.SetGlyph(wafer.X, wafer.Y, 249, Xna.Color.Black, Xna.Color.DarkSeaGreen)

        
def main():
    SadConsole.Engine.Initialize("SadConsole/Cheepicus12.font", 50, 60)

    SadConsole.Engine.EngineStart += EngineStart

    SadConsole.Engine.EngineUpdated += EngineUpdated

    SadConsole.Engine.EngineDrawFrame += EngineDrawFrame
    
    try:
        SadConsole.Engine.Run()
        
    except System.Exception as e:
        print(e)
    
    
# ==== Called by SadConsole when this script executes
def EngineStart(sender, args):
    global phoneConsole
    
    phoneConsole = Console(50, 60)
    

    # Create the phone surface
    phoneConsole.SetGlyph(11, 55, 200, Xna.Color.White)
    phoneConsole.SetGlyph(39, 55, 188, Xna.Color.White)
    phoneConsole.KeyboardHandler = System.Func[SadConsole.Consoles.IConsole,SadConsole.Input.KeyboardInfo,System.Boolean](KeyboardHandlerMain)


    SadConsole.Engine.ActiveConsole = phoneConsole

    for x in range(12, 39):
        phoneConsole.SetGlyph(x, 55, 205, Xna.Color.White)

    for y in range(30, 55):
        phoneConsole.SetGlyph(11, y, 186, Xna.Color.White)
        phoneConsole.SetGlyph(39, y, 186, Xna.Color.White)

    phoneConsole.SetGlyph(11, 29, 187, Xna.Color.White)
    phoneConsole.SetGlyph(39, 29, 201, Xna.Color.White)
    phoneConsole.SetGlyph(10, 29, 200, Xna.Color.White)
    phoneConsole.SetGlyph(40, 29, 188, Xna.Color.White)

    for y in range(5, 29):
        phoneConsole.SetGlyph(10, y, 186, Xna.Color.White)
        phoneConsole.SetGlyph(40, y, 186, Xna.Color.White)
    
    phoneConsole.SetGlyph(10, 4, 201, Xna.Color.White)
    phoneConsole.SetGlyph(40, 4, 187, Xna.Color.White)

    for x in range(11, 40):
        phoneConsole.SetGlyph(x, 4, 205, Xna.Color.White)
    

    DrawPhoneButton(phoneButtonColumn1, phoneButtonRow1, "1")
    DrawPhoneButton(phoneButtonColumn2, phoneButtonRow1, "2")
    DrawPhoneButton(phoneButtonColumn3, phoneButtonRow1, "3")
    DrawPhoneButton(phoneButtonColumn1, phoneButtonRow2, "4")
    DrawPhoneButton(phoneButtonColumn2, phoneButtonRow2, "5")
    DrawPhoneButton(phoneButtonColumn3, phoneButtonRow2, "6")
    DrawPhoneButton(phoneButtonColumn1, phoneButtonRow3, "7")
    DrawPhoneButton(phoneButtonColumn2, phoneButtonRow3, "8")
    DrawPhoneButton(phoneButtonColumn3, phoneButtonRow3, "9")
    DrawPhoneButton(phoneButtonColumn1, phoneButtonRow4, "*")
    DrawPhoneButton(phoneButtonColumn2, phoneButtonRow4, "0")
    DrawPhoneButton(phoneButtonColumn3, phoneButtonRow4, "#")


    # Draw mic
    for x in range(24, 27):
        phoneConsole.SetGlyph(x, 53, 240, Xna.Color.DarkGray)

    # Draw plate
    for x in range(12, 39):
        for y in range(6, 28):
            phoneConsole.SetGlyph(x, y, 178, Xna.Color.Silver)

    for x in range(13, 38):
        for y in range(28, 30):
            phoneConsole.SetGlyph(x, y, 178, Xna.Color.Silver)

    # Draw speaker
    for x in range(22, 29):
        phoneConsole.SetGlyph(x, 7, 240, Xna.Color.Black, Xna.Color.Silver)
    

    # Draw brand
    phoneConsole.Print(23, 10, "NOKIA", Xna.Color.White, Xna.Color.Silver)

    # End/Call buttons
    for x in range(phoneButtonColumn1, phoneButtonColumn1 + 7):
        for y in range(26, 29):
            phoneConsole.SetGlyph(x, y, 219, Xna.Color.Gray)
    phoneConsole.Print(phoneButtonColumn1 + 2, 27, "End", Xna.Color.Red, Xna.Color.Gray)

    for x in range(phoneButtonColumn3 - 2, phoneButtonColumn3 - 2 + 7):
        for y in range(26, 29):
            phoneConsole.SetGlyph(x, y, 219, Xna.Color.Gray)
    phoneConsole.Print(phoneButtonColumn3 - 1, 27, "Call", Xna.Color.Green, Xna.Color.Gray)

    ClearScreen()
    CreateStartMessage()

    SadConsole.Engine.ConsoleRenderStack.Add(phoneConsole)
    
    
# ==== Called by SadConsole when the render pass happens
def EngineDrawFrame(sender, args):
    pass

# ==== Called by SadConsole when the update pass happens
def EngineUpdated(sender, args):
    global lastUpdate, currentScore

    if gameState == gameStateRunning:
        if lastUpdate.Add(gameSpeed).Ticks < DateTime.Now.Ticks:
            lastUpdate = DateTime.Now

            # Move the player and update the tail
            player.Move()
            player.ProcessTail(player.Position)

            # Erase old points
            for pos in player.RemoveNodes:
                phoneConsole.SetGlyph(pos.X, pos.Y, 0);

            # New position
            phoneConsole.SetGlyph(player.Position.X, player.Position.Y, 1, Xna.Color.Black, Xna.Color.DarkSeaGreen)

            # Check for bad collision
            if CollisionDetection(player.Position):
                EndGame()

            # Check for wafer, eat, grow, create new wafer
            if (player.Position.X == wafer.X) and (player.Position.Y == wafer.Y):
                currentScore += 3
                DrawScore()
                player.MaxTailLength += 1

                CreateRandomWaferLocation()

                phoneConsole.SetGlyph(wafer.X, wafer.Y, 249, Xna.Color.Black, Xna.Color.DarkSeaGreen)

if  __name__ =='__main__':main()