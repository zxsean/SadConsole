﻿using Microsoft.Xna.Framework;

namespace RoguelikeGame.MapObjects
{
    public class Floor : MapObjectBase
    {
        public Floor() : base(Color.DarkGray, Color.Transparent, 46)
        {
        }

        // If you're looking at this code, this is extra customization I did but didn't put into the tutorial.
        public override void RenderToCell(SadConsole.Cell sadConsoleCell, RogueSharp.Cell rogueSharpCell)
        {
            base.RenderToCell(sadConsoleCell, rogueSharpCell);

            if (rogueSharpCell.IsInFov)
            {
                sadConsoleCell.CharacterIndex = 46;
            }
        }

        public override void RemoveCellFromView(SadConsole.Cell sadConsoleCell)
        {
            base.RemoveCellFromView(sadConsoleCell);

            sadConsoleCell.CharacterIndex = 0;
        }
    }
}
