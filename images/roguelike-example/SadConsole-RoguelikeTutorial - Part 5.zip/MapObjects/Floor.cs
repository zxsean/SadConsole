﻿using Microsoft.Xna.Framework;

namespace RoguelikeGame.MapObjects
{
    public class Floor : MapObjectBase
    {
        public Floor() : base(Color.DarkGray, Color.Transparent, 46)
        {
        }

        // If you're looking at this code, this is extra customization I did but didn't put into the tutorial.
        public override void RenderToCell(SadConsole.Cell sadConsoleCell, bool isFov, bool isExplored)
        {
            base.RenderToCell(sadConsoleCell, isFov, isExplored);

            if (isFov)
            {
                sadConsoleCell.GlyphIndex = 46;
            }
        }

        public override void RemoveCellFromView(SadConsole.Cell sadConsoleCell)
        {
            base.RemoveCellFromView(sadConsoleCell);

            sadConsoleCell.GlyphIndex = 0;
        }
    }
}
