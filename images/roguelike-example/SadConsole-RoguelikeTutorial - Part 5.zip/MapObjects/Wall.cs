﻿using Microsoft.Xna.Framework;

namespace RoguelikeGame.MapObjects
{
    public class Wall : MapObjectBase
    {
        public Wall() : base(Color.White, Color.Gray, 176)
        {
        }
    }
}
