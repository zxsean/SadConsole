﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SadConsole;
using Microsoft.Xna.Framework;

namespace RoguelikeGame.Consoles
{
    class MessagesConsole: SadConsole.Consoles.Console
    {
        
        public MessagesConsole(int width, int height):base(width, height)
        {
        }

        public void PrintMessage(string text)
        {
            CellData.ShiftDown(1);
            VirtualCursor.Print(text).CarriageReturn();
        }

        public void PrintMessage(ColoredString text)
        {
            CellData.ShiftDown(1);
            VirtualCursor.Print(text).CarriageReturn();
        }
    }
}
