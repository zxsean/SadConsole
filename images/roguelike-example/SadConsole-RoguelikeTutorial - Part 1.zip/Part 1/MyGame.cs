﻿using Microsoft.Xna.Framework;


namespace RoguelikeGame
{
    class MyGame: Game
    {
        GraphicsDeviceManager graphics;

        public MyGame()
        {
            graphics = new GraphicsDeviceManager(this);

            var sadConsoleComponent = new SadConsole.EngineGameComponent(this, () =>
            {
                SadConsole.Engine.Initialize(GraphicsDevice);

                using (var stream = System.IO.File.OpenRead("Fonts/IBM.font"))
                    SadConsole.Engine.DefaultFont = SadConsole.Serializer.Deserialize<SadConsole.Font>(stream);

                SadConsole.Engine.Fonts.Add(SadConsole.Engine.DefaultFont.Name, SadConsole.Engine.DefaultFont, true);

                int width = 80;
                int height = 24;

                SadConsole.Engine.DefaultFont.ResizeGraphicsDeviceManager(graphics, width, height, 0, 0);

                SadConsole.Consoles.Console testConsole = new SadConsole.Consoles.Console(80, 24);

                testConsole.CellData.Print(2, 2, "Hello world");

                SadConsole.Engine.ConsoleRenderStack.Add(testConsole);
            });

            Components.Add(sadConsoleComponent);
        }
    }
}
