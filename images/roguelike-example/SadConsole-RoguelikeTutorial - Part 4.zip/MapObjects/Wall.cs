﻿using Microsoft.Xna.Framework;
using SadConsole;

namespace RoguelikeGame.MapObjects
{
    public class Wall : CellAppearance
    {
        public Wall() : base(Color.White, Color.Gray, 176)
        {

        }
    }
}
