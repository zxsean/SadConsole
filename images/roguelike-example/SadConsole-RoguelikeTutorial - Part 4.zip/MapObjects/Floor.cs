﻿using Microsoft.Xna.Framework;
using SadConsole;

namespace RoguelikeGame.MapObjects
{
    public class Floor : CellAppearance
    {
        public Floor() : base(Color.DarkGray, Color.Transparent, 46)
        {

        }
    }
}
