﻿using Microsoft.Xna.Framework;


namespace RoguelikeGame
{
    class MyGame: Game
    {
        GraphicsDeviceManager graphics;

        public MyGame()
        {
            graphics = new GraphicsDeviceManager(this);

            var sadConsoleComponent = new SadConsole.EngineGameComponent(this, () =>
            {
                SadConsole.Engine.Initialize(GraphicsDevice);

                using (var stream = System.IO.File.OpenRead("Fonts/IBM.font"))
                    SadConsole.Engine.DefaultFont = SadConsole.Serializer.Deserialize<SadConsole.Font>(stream);

                SadConsole.Engine.Fonts.Add(SadConsole.Engine.DefaultFont.Name, SadConsole.Engine.DefaultFont, true);

                int width = 80;
                int height = 24;

                SadConsole.Engine.DefaultFont.ResizeGraphicsDeviceManager(graphics, width, height, 0, 0);

                var viewConsole = new BorderedConsole(56, 18);
                var statsConsole = new BorderedConsole(" Status ", 24, 18);
                var messageConsole = new BorderedConsole(" Messages ", 80, 6);

                viewConsole.Position = new Point(0, 0);
                statsConsole.Position = new Point(56, 0);
                messageConsole.Position = new Point(0, 18);

                SadConsole.Engine.ConsoleRenderStack.Add(viewConsole);
                SadConsole.Engine.ConsoleRenderStack.Add(statsConsole);
                SadConsole.Engine.ConsoleRenderStack.Add(messageConsole);


            });

            Components.Add(sadConsoleComponent);
        }
    }
}
