﻿using System;
using Microsoft.Xna.Framework;
using Console = SadConsole.Consoles.Console;

namespace RoguelikeGame
{
    class Program
    {
        static void Main(string[] args)
        {
            // Setup the engine and creat the main window.
            SadConsole.Engine.Initialize("IBM.font", 80, 25);

            // Hook the start event so we can add consoles to the system.
            SadConsole.Engine.EngineStart += Engine_EngineStart;

            // Hook the update event that happens each frame so we can trap keys and respond.
            SadConsole.Engine.EngineUpdated += Engine_EngineUpdated;

            // Start the game.
            SadConsole.Engine.Run();
        }

        private static void Engine_EngineStart(object sender, EventArgs e)
        {
            // Clear the default console
            SadConsole.Engine.ConsoleRenderStack.Clear();
            SadConsole.Engine.ActiveConsole = null;

            var viewConsole = new BorderedConsole(56, 18);
            var statsConsole = new BorderedConsole(" Status ", 24, 18);
            var messageConsole = new BorderedConsole(" Messages ", 80, 7);

            viewConsole.Position = new Point(0, 0);
            statsConsole.Position = new Point(56, 0);
            messageConsole.Position = new Point(0, 18);

            SadConsole.Engine.ConsoleRenderStack.Add(viewConsole);
            SadConsole.Engine.ConsoleRenderStack.Add(statsConsole);
            SadConsole.Engine.ConsoleRenderStack.Add(messageConsole);
        }

        private static void Engine_EngineUpdated(object sender, EventArgs e)
        {

        }
    }

}
