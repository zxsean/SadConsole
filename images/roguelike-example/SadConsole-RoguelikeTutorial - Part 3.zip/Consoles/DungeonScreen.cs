﻿using Microsoft.Xna.Framework;
using SadConsole.Consoles;
using System;
using Console = SadConsole.Consoles.Console;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RoguelikeGame.Consoles
{
    class DungeonScreen: ConsoleList
    {
        public Console ViewConsole;
        public CharacterStatusPanel StatsConsole;
        public MessagesConsole MessageConsole;

        private CellsRenderer messageHeaderConsole;

        public DungeonScreen()
        {
            StatsConsole = new CharacterStatusPanel(24, 18);
            ViewConsole = new Console(56, 18); ViewConsole.FillWithRandomGarbage();
            MessageConsole = new MessagesConsole(80, 6);

            // Setup the message header to be as wide as the screen but only 1 character high
            messageHeaderConsole = new CellsRenderer(new SadConsole.CellSurface(80, 1), new Microsoft.Xna.Framework.Graphics.SpriteBatch(SadConsole.Engine.Device));
            
            // Draw the line for the header
            messageHeaderConsole.CellData.Fill(Color.White, Color.Black, 196, null);
            messageHeaderConsole.CellData.SetCharacter(56, 0, 193); // This makes the border match the character console's left-edge border

            // Print the header text
            messageHeaderConsole.CellData.Print(2, 0, " Messages ");


            // Move the rest of the consoles into position (ViewConsole is already in position at 0,0)
            StatsConsole.Position = new Point(56, 0);
            MessageConsole.Position = new Point(0, 18);
            messageHeaderConsole.Position = new Point(0, 17);

            // Add all consoles to this console list.
            Add(StatsConsole);
            Add(ViewConsole);
            Add(MessageConsole);

            // Placeholder stuff for the stats screen
            StatsConsole.CharacterName = "Hydorn";
            StatsConsole.MaxHealth = 200;
            StatsConsole.Health = 100;
        }

        public override void Render()
        {
            // Render all the consoles we added
            base.Render();

            // Render our special non-console to the screen
            messageHeaderConsole.Render();
        }
    }
}
